<?php
 define('HOST','localhost');
 define('USER','imdhru5_aug338');
 define('PASS','dhrup@123');
 define('DB','imdhru5_dhaug2017_338');
 
 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
?>
angular.module('ionic-datepicker', [
  'ionic',
  'ionic-datepicker.service',
  'ionic-datepicker.provider',
  'ionic-datepicker.templates'
]);
